# edge_camera_v10 正式工程

从冻结V9接续整理，功能和接线保持，工程名及顶层为edge_camera_v10/edge_camera_v10_top。V1～V9只读保存。本次用户要求仅重新编译生成bit，不下载板卡、不写Flash；V10硬件验收不能沿用V9结果。

保留完整1920×1080 Sobel/Canny、精确8连通及同RAW无迭代上限回退、480×270形状识别、摄像头有效FPS、四位数码管、矩阵按键、历史回放、A/B比较、白平衡和原调试能力。当前已知形状识别限制继续保留。

## 编译与维护

目标Ti60F225I3；Efinity2026.1.132安装在D:/Efinity。固定Python：C:/Users/liu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe，始终带-X utf8 -B。

```powershell
python -X utf8 -B scripts/project.py check
python -X utf8 -B scripts/project.py build
python -X utf8 -B scripts/project.py validate
```

上面的python应替换为固定运行时路径；也可用Efinity直接打开edge_camera_v10.xml编译。所有源码、约束、IP、测试数据和维护工具均位于本工程；不需要V8/V9工程存在。provenance中的旧路径仅用于来源审计。

单项仿真：`python -X utf8 -B scripts/simulate_xsim.py tb_v9_camera_fps --isolated`。完整39项测试及变体：`python -X utf8 -B scripts/project.py test`；已安装XSim2023.1，仅用于可移植RTL仿真，不迁移Vivado实现。临时仿真产物写入build/sim，输入fixture保持只读使用。

维护脚本仅保留project.py、vendor.py、simulate_xsim.py、regression.py、validate.py和权威形状生成源write_shape_detector_upgrade_v8.py。后者及继承模块的v8_/v9_前缀表示来源，不代表运行时需要旧工程。禁止全局改名加密IP或改写厂商文件。

## 清理边界

剔除7个未被当前顶层引用的旧RTL模块及XML引用；不带入旧版本完整副本、失败实验、过去的Flash备份、历史文档生成/冻结/烧录脚本、旧仿真测试及缓存。厂商vendor/IP/debug包按字节完整保留，必要的1080p黄金测试数据仍保留，因此测试fixture占大部分源码目录体积。详见docs/清理清单.md。

原左图FPS兼容分支仍被通用显示模块引用，保留定义以保证源码不改动和可编译；当前顶层启用摄像头有效FPS。当前实际功能路径RTL逐字节继承V9，仅顶层版本标识改为V10。

## 按键和显示

详见docs/按键与显示.md。默认Sobel20、中值开启、灰度、形状112档开启，数码管S020。左半屏右上状态行绿色摄像头有效帧率按完整有效RAW提交captured统计；冻结画面不使摄像头有效FPS归零。

## 验证与限制

最终构建、bit散列、资源和时序以reports/validation_v10.json及reports/build_v10.json为准；来源和原执行记录嵌入provenance，验证不读取旧工程。2项V10快速测试已重新执行，其余仅在实际依赖/fixture/参数完全一致时采用既有测试证据；不声称39项全新运行。

复杂背景255标签可能耗尽，小图/空心及快速移动问题未全面实物验收，纸面限定尚未实现；Canny精确无上限回退可能很慢。正式版整理不表示这些问题已经解决。V10尚未实板验收，本次不下载板卡。

本次生成的临时编译/仿真缓存已移到工程外E:/Efinity-DOC/tmp/v10_build_cache_20261103，不在正式工程包内；未擦除数据。

## 本次正式版构建结果

编译和核验PASS，bit文件outflow/edge_camera_v10.bit，SHA256 `36e1e5c3d2c3e49f56c66c0166cf3eb412e902dda73c8eac1edd0407339744d0`。建立裕量最小+0.040ns，保持裕量最小+0.027ns，CSI输入hold uncertainty0.570ns；XLR60712/60800，RAM255/256，DSP17/160，GBUF11/32。V9冻结419项文件复核无变化。

正式工程包release/edge_camera_v10_project.zip，包含当前源码、约束、IP、必要测试/fixture、维护工具、bit及验证报告；不含生成缓存。当前V10未下载板卡、未写Flash、未冻结。
